package io.github.sceneview.sample.arcursorplacement

interface OnModelClickListener {
    fun onModelClick(model: Model)
}